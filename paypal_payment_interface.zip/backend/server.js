
const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());

const PAYPAL_CLIENT = process.env.PAYPAL_CLIENT;
const PAYPAL_SECRET = process.env.PAYPAL_SECRET;
const PAYPAL_API = 'https://api-m.sandbox.paypal.com';

app.post('/create-payment', async (req, res) => {
  try {
    const { data } = await axios.post(
      `${PAYPAL_API}/v1/oauth2/token`,
      'grant_type=client_credentials',
      {
        auth: {
          username: PAYPAL_CLIENT,
          password: PAYPAL_SECRET,
        },
      }
    );
    res.json({ access_token: data.access_token });
  } catch (error) {
    console.error(error);
    res.status(500).send('Error creating token.');
  }
});

app.post('/payout', async (req, res) => {
  const { email, amount } = req.body;
  try {
    const { data } = await axios.post(
      `${PAYPAL_API}/v1/payments/payouts`,
      {
        sender_batch_header: {
          email_subject: 'You have a payment!',
        },
        items: [
          {
            recipient_type: 'EMAIL',
            amount: {
              value: amount,
              currency: 'USD',
            },
            receiver: email,
          },
        ],
      },
      {
        headers: {
          Authorization: `Bearer ${req.headers.authorization}`,
        },
      }
    );
    res.json(data);
  } catch (error) {
    console.error(error.response.data);
    res.status(500).send('Error processing payout.');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
